
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Multi-Agent 协同运营自动化系统（标准库版）
------------------------------------------------
功能：
1. 多 Agent 协同：Planner / Copywriter / Ops / Analyst / QA / Executor
2. 自动任务拆解：把一个运营目标拆成可执行步骤
3. Agent 路由：按任务类型分配给合适 Agent
4. 共享记忆：SQLite 存储任务、运行记录、事件日志、知识库
5. 定时自动化：支持一次性任务、间隔任务、每日定时任务
6. HTTP API：创建任务、查看任务、查看运行状态、查看事件
7. CLI：命令行提交任务、启动服务、启动调度器
8. 可替换 LLM：默认 MockLLM，可自行接入任意大模型接口

运行：
    python main.py serve
    python main.py task "帮我做一套小红书引流运营方案"
    python main.py worker

API 示例：
    curl -X POST http://127.0.0.1:8765/tasks \
      -H "Content-Type: application/json" \
      -d '{"title":"小红书运营","goal":"做一套小红书引流运营方案","channel":"xiaohongshu"}'

注意：
    这是一个完整可运行骨架。真实生产环境中，你需要把 MockLLM 换成你自己的 LLMClient，
    并把 ToolRegistry 中的工具接入真实平台，比如飞书、企微、Notion、抖音、小红书、CRM 等。
"""

from __future__ import annotations

import argparse
import dataclasses
import datetime as dt
import hashlib
import http.server
import json
import os
import queue
import random
import re
import sqlite3
import sys
import threading
import time
import traceback
import urllib.parse
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple


# =========================
# 基础工具
# =========================

def now_iso() -> str:
    return dt.datetime.now().replace(microsecond=0).isoformat()


def utc_ts() -> int:
    return int(time.time())


def stable_id(prefix: str, text: str) -> str:
    h = hashlib.sha256((prefix + text + str(time.time_ns())).encode("utf-8")).hexdigest()[:12]
    return f"{prefix}_{h}"


def dumps(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, indent=2)


def loads(s: str, default: Any = None) -> Any:
    try:
        return json.loads(s)
    except Exception:
        return default


def clean_text(s: str) -> str:
    return re.sub(r"\s+", " ", s or "").strip()


# =========================
# 数据模型
# =========================

class TaskStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"


class StepStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class Task:
    id: str
    title: str
    goal: str
    channel: str = "general"
    priority: int = 5
    status: TaskStatus = TaskStatus.PENDING
    created_at: str = field(default_factory=now_iso)
    updated_at: str = field(default_factory=now_iso)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Step:
    id: str
    task_id: str
    order_no: int
    agent_name: str
    action: str
    input_data: Dict[str, Any]
    status: StepStatus = StepStatus.PENDING
    output_data: Dict[str, Any] = field(default_factory=dict)
    error: str = ""
    created_at: str = field(default_factory=now_iso)
    updated_at: str = field(default_factory=now_iso)


@dataclass
class Event:
    id: str
    task_id: str
    level: str
    message: str
    data: Dict[str, Any] = field(default_factory=dict)
    created_at: str = field(default_factory=now_iso)


@dataclass
class Schedule:
    id: str
    title: str
    goal: str
    channel: str = "general"
    kind: str = "interval"  # once | interval | daily
    interval_seconds: int = 3600
    run_at: Optional[str] = None          # once: ISO datetime
    daily_time: Optional[str] = None      # daily: HH:MM
    enabled: bool = True
    last_run_ts: int = 0
    created_at: str = field(default_factory=now_iso)


# =========================
# SQLite 记忆和状态存储
# =========================

class Store:
    def __init__(self, db_path: str = "ops_agent.db"):
        self.db_path = db_path
        self._lock = threading.RLock()
        self.init()

    def conn(self) -> sqlite3.Connection:
        c = sqlite3.connect(self.db_path, check_same_thread=False)
        c.row_factory = sqlite3.Row
        return c

    def init(self) -> None:
        with self._lock, self.conn() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS tasks (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                goal TEXT NOT NULL,
                channel TEXT NOT NULL,
                priority INTEGER NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                metadata TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS steps (
                id TEXT PRIMARY KEY,
                task_id TEXT NOT NULL,
                order_no INTEGER NOT NULL,
                agent_name TEXT NOT NULL,
                action TEXT NOT NULL,
                input_data TEXT NOT NULL,
                status TEXT NOT NULL,
                output_data TEXT NOT NULL,
                error TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS events (
                id TEXT PRIMARY KEY,
                task_id TEXT NOT NULL,
                level TEXT NOT NULL,
                message TEXT NOT NULL,
                data TEXT NOT NULL,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS knowledge (
                id TEXT PRIMARY KEY,
                namespace TEXT NOT NULL,
                key TEXT NOT NULL,
                value TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                UNIQUE(namespace, key)
            );

            CREATE TABLE IF NOT EXISTS schedules (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                goal TEXT NOT NULL,
                channel TEXT NOT NULL,
                kind TEXT NOT NULL,
                interval_seconds INTEGER NOT NULL,
                run_at TEXT,
                daily_time TEXT,
                enabled INTEGER NOT NULL,
                last_run_ts INTEGER NOT NULL,
                created_at TEXT NOT NULL
            );
            """)
            c.commit()

    def create_task(self, title: str, goal: str, channel: str = "general",
                    priority: int = 5, metadata: Optional[Dict[str, Any]] = None) -> Task:
        task = Task(
            id=stable_id("task", title + goal),
            title=title,
            goal=goal,
            channel=channel,
            priority=priority,
            metadata=metadata or {},
        )
        with self._lock, self.conn() as c:
            c.execute("""
                INSERT INTO tasks VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                task.id, task.title, task.goal, task.channel, task.priority, task.status.value,
                task.created_at, task.updated_at, dumps(task.metadata)
            ))
            c.commit()
        self.add_event(task.id, "info", "task_created", dataclasses.asdict(task))
        return task

    def update_task_status(self, task_id: str, status: TaskStatus) -> None:
        with self._lock, self.conn() as c:
            c.execute("UPDATE tasks SET status=?, updated_at=? WHERE id=?",
                      (status.value, now_iso(), task_id))
            c.commit()
        self.add_event(task_id, "info", f"task_status_{status.value}", {})

    def get_task(self, task_id: str) -> Optional[Task]:
        with self.conn() as c:
            r = c.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
            if not r:
                return None
            return Task(
                id=r["id"], title=r["title"], goal=r["goal"], channel=r["channel"],
                priority=r["priority"], status=TaskStatus(r["status"]),
                created_at=r["created_at"], updated_at=r["updated_at"],
                metadata=loads(r["metadata"], {})
            )

    def list_tasks(self, limit: int = 50, status: Optional[str] = None) -> List[Dict[str, Any]]:
        with self.conn() as c:
            if status:
                rows = c.execute("SELECT * FROM tasks WHERE status=? ORDER BY created_at DESC LIMIT ?",
                                 (status, limit)).fetchall()
            else:
                rows = c.execute("SELECT * FROM tasks ORDER BY created_at DESC LIMIT ?",
                                 (limit,)).fetchall()
            return [dict(r) | {"metadata": loads(r["metadata"], {})} for r in rows]

    def add_step(self, step: Step) -> None:
        with self._lock, self.conn() as c:
            c.execute("""
                INSERT INTO steps VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                step.id, step.task_id, step.order_no, step.agent_name, step.action,
                dumps(step.input_data), step.status.value, dumps(step.output_data),
                step.error, step.created_at, step.updated_at
            ))
            c.commit()
        self.add_event(step.task_id, "info", "step_created", dataclasses.asdict(step))

    def update_step(self, step_id: str, status: StepStatus,
                    output_data: Optional[Dict[str, Any]] = None, error: str = "") -> None:
        output_data = output_data or {}
        with self._lock, self.conn() as c:
            c.execute("""
                UPDATE steps
                SET status=?, output_data=?, error=?, updated_at=?
                WHERE id=?
            """, (status.value, dumps(output_data), error, now_iso(), step_id))
            task_id = c.execute("SELECT task_id FROM steps WHERE id=?", (step_id,)).fetchone()
            c.commit()
        if task_id:
            self.add_event(task_id["task_id"], "info" if not error else "error",
                           f"step_status_{status.value}", {"step_id": step_id, "error": error})

    def list_steps(self, task_id: str) -> List[Step]:
        with self.conn() as c:
            rows = c.execute("SELECT * FROM steps WHERE task_id=? ORDER BY order_no ASC", (task_id,)).fetchall()
            return [
                Step(
                    id=r["id"], task_id=r["task_id"], order_no=r["order_no"],
                    agent_name=r["agent_name"], action=r["action"],
                    input_data=loads(r["input_data"], {}),
                    status=StepStatus(r["status"]),
                    output_data=loads(r["output_data"], {}),
                    error=r["error"], created_at=r["created_at"], updated_at=r["updated_at"]
                )
                for r in rows
            ]

    def add_event(self, task_id: str, level: str, message: str, data: Optional[Dict[str, Any]] = None) -> Event:
        ev = Event(
            id=stable_id("evt", task_id + message),
            task_id=task_id,
            level=level,
            message=message,
            data=data or {},
        )
        with self._lock, self.conn() as c:
            c.execute("INSERT INTO events VALUES (?, ?, ?, ?, ?, ?)",
                      (ev.id, ev.task_id, ev.level, ev.message, dumps(ev.data), ev.created_at))
            c.commit()
        return ev

    def list_events(self, task_id: Optional[str] = None, limit: int = 100) -> List[Dict[str, Any]]:
        with self.conn() as c:
            if task_id:
                rows = c.execute("SELECT * FROM events WHERE task_id=? ORDER BY created_at DESC LIMIT ?",
                                 (task_id, limit)).fetchall()
            else:
                rows = c.execute("SELECT * FROM events ORDER BY created_at DESC LIMIT ?",
                                 (limit,)).fetchall()
            return [dict(r) | {"data": loads(r["data"], {})} for r in rows]

    def set_knowledge(self, namespace: str, key: str, value: Any) -> None:
        now = now_iso()
        with self._lock, self.conn() as c:
            c.execute("""
                INSERT INTO knowledge(id, namespace, key, value, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(namespace, key)
                DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at
            """, (stable_id("mem", namespace + key), namespace, key, dumps(value), now, now))
            c.commit()

    def get_knowledge(self, namespace: str, key: str, default: Any = None) -> Any:
        with self.conn() as c:
            r = c.execute("SELECT value FROM knowledge WHERE namespace=? AND key=?",
                          (namespace, key)).fetchone()
            return loads(r["value"], default) if r else default

    def search_knowledge(self, namespace: str, keyword: str, limit: int = 20) -> List[Dict[str, Any]]:
        with self.conn() as c:
            rows = c.execute("""
                SELECT * FROM knowledge
                WHERE namespace=? AND (key LIKE ? OR value LIKE ?)
                ORDER BY updated_at DESC LIMIT ?
            """, (namespace, f"%{keyword}%", f"%{keyword}%", limit)).fetchall()
            return [dict(r) | {"value": loads(r["value"], {})} for r in rows]

    def create_schedule(self, schedule: Schedule) -> Schedule:
        with self._lock, self.conn() as c:
            c.execute("""
                INSERT INTO schedules VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                schedule.id, schedule.title, schedule.goal, schedule.channel,
                schedule.kind, schedule.interval_seconds, schedule.run_at,
                schedule.daily_time, 1 if schedule.enabled else 0,
                schedule.last_run_ts, schedule.created_at
            ))
            c.commit()
        return schedule

    def list_schedules(self) -> List[Schedule]:
        with self.conn() as c:
            rows = c.execute("SELECT * FROM schedules ORDER BY created_at DESC").fetchall()
            return [
                Schedule(
                    id=r["id"], title=r["title"], goal=r["goal"], channel=r["channel"],
                    kind=r["kind"], interval_seconds=r["interval_seconds"],
                    run_at=r["run_at"], daily_time=r["daily_time"],
                    enabled=bool(r["enabled"]), last_run_ts=r["last_run_ts"],
                    created_at=r["created_at"],
                )
                for r in rows
            ]

    def mark_schedule_run(self, schedule_id: str) -> None:
        with self._lock, self.conn() as c:
            c.execute("UPDATE schedules SET last_run_ts=? WHERE id=?", (utc_ts(), schedule_id))
            c.commit()

    def disable_schedule(self, schedule_id: str) -> None:
        with self._lock, self.conn() as c:
            c.execute("UPDATE schedules SET enabled=0 WHERE id=?", (schedule_id,))
            c.commit()


# =========================
# LLM 抽象
# =========================

class LLMClient:
    def complete(self, system: str, prompt: str, temperature: float = 0.3) -> str:
        raise NotImplementedError


class MockLLM(LLMClient):
    """
    无 API Key 也能跑的模拟 LLM。
    生产环境请替换为真实 LLM。
    """
    def complete(self, system: str, prompt: str, temperature: float = 0.3) -> str:
        p = prompt.lower()

        if "拆解" in prompt or "plan" in p:
            return dumps({
                "steps": [
                    {
                        "agent_name": "analyst",
                        "action": "analyze_context",
                        "input_data": {"need": "分析目标、渠道、用户、限制和关键指标"}
                    },
                    {
                        "agent_name": "copywriter",
                        "action": "create_content_plan",
                        "input_data": {"need": "生成运营内容策略、话术、发布节奏"}
                    },
                    {
                        "agent_name": "ops",
                        "action": "create_execution_plan",
                        "input_data": {"need": "生成落地动作、排期、SOP、风险点"}
                    },
                    {
                        "agent_name": "qa",
                        "action": "review_outputs",
                        "input_data": {"need": "检查是否合规、是否可执行、是否遗漏"}
                    },
                    {
                        "agent_name": "executor",
                        "action": "finalize",
                        "input_data": {"need": "汇总为最终交付物"}
                    }
                ]
            })

        if "质检" in prompt or "review" in p:
            return dumps({
                "passed": True,
                "score": 86,
                "issues": [
                    "需要结合真实平台规则做二次校验",
                    "需要补充预算、人员和转化目标"
                ],
                "suggestions": [
                    "每周复盘一次转化数据",
                    "所有外部联系方式引导都使用合规表达"
                ]
            })

        return (
            "已完成该步骤。输出包括：目标拆解、关键动作、风险点、执行清单、复盘指标。"
            "这是 MockLLM 的结果；接入真实 LLM 后会生成更细的内容。"
        )


# =========================
# 工具系统
# =========================

class ToolRegistry:
    def __init__(self, store: Store):
        self.store = store
        self.tools: Dict[str, Callable[..., Any]] = {}
        self.register_defaults()

    def register(self, name: str, func: Callable[..., Any]) -> None:
        self.tools[name] = func

    def call(self, name: str, **kwargs: Any) -> Any:
        if name not in self.tools:
            raise ValueError(f"Tool not found: {name}")
        return self.tools[name](**kwargs)

    def register_defaults(self) -> None:
        self.register("save_memory", self.save_memory)
        self.register("search_memory", self.search_memory)
        self.register("generate_checklist", self.generate_checklist)
        self.register("score_plan", self.score_plan)
        self.register("mock_publish", self.mock_publish)
        self.register("mock_notify", self.mock_notify)

    def save_memory(self, namespace: str, key: str, value: Any) -> Dict[str, Any]:
        self.store.set_knowledge(namespace, key, value)
        return {"ok": True, "namespace": namespace, "key": key}

    def search_memory(self, namespace: str, keyword: str, limit: int = 20) -> List[Dict[str, Any]]:
        return self.store.search_knowledge(namespace, keyword, limit)

    def generate_checklist(self, title: str, items: List[str]) -> Dict[str, Any]:
        return {
            "title": title,
            "items": [{"done": False, "text": i} for i in items]
        }

    def score_plan(self, plan_text: str) -> Dict[str, Any]:
        score = 60
        must_have = ["目标", "用户", "渠道", "内容", "转化", "复盘", "风险"]
        hits = [w for w in must_have if w in plan_text]
        score += len(hits) * 5
        return {
            "score": min(score, 100),
            "hits": hits,
            "missing": [w for w in must_have if w not in hits]
        }

    def mock_publish(self, channel: str, content: str) -> Dict[str, Any]:
        # 真实生产中在这里接平台 API。
        return {
            "ok": True,
            "channel": channel,
            "publish_id": stable_id("pub", channel + content),
            "message": "模拟发布成功"
        }

    def mock_notify(self, target: str, content: str) -> Dict[str, Any]:
        # 真实生产中在这里接企业微信、飞书、邮件、短信。
        return {
            "ok": True,
            "target": target,
            "message": "模拟通知成功",
            "content_preview": content[:100]
        }


# =========================
# Agent 定义
# =========================

class Agent:
    name = "base"
    role = "base agent"

    def __init__(self, llm: LLMClient, tools: ToolRegistry, store: Store):
        self.llm = llm
        self.tools = tools
        self.store = store

    def run(self, task: Task, step: Step, previous_outputs: List[Dict[str, Any]]) -> Dict[str, Any]:
        raise NotImplementedError

    def llm_json(self, system: str, prompt: str) -> Dict[str, Any]:
        text = self.llm.complete(system, prompt)
        obj = loads(text)
        if obj is None:
            return {"raw": text}
        return obj


class PlannerAgent(Agent):
    name = "planner"
    role = "把运营目标拆成多 Agent 可执行步骤"

    def plan(self, task: Task) -> List[Dict[str, Any]]:
        system = "你是运营自动化系统的任务规划 Agent。你负责把目标拆解成多 Agent 协作步骤。"
        prompt = f"""
请拆解这个运营目标，输出 JSON：
任务标题：{task.title}
目标：{task.goal}
渠道：{task.channel}

要求：
- 返回形如 {{"steps":[...]}} 的 JSON
- 每个 step 包含 agent_name, action, input_data
- agent_name 只能是 analyst/copywriter/ops/qa/executor
- 步骤要能串联完成完整运营交付
"""
        data = self.llm_json(system, prompt)
        steps = data.get("steps") if isinstance(data, dict) else None
        if not steps:
            steps = [
                {"agent_name": "analyst", "action": "analyze_context", "input_data": {}},
                {"agent_name": "copywriter", "action": "create_content_plan", "input_data": {}},
                {"agent_name": "ops", "action": "create_execution_plan", "input_data": {}},
                {"agent_name": "qa", "action": "review_outputs", "input_data": {}},
                {"agent_name": "executor", "action": "finalize", "input_data": {}},
            ]
        return steps


class AnalystAgent(Agent):
    name = "analyst"
    role = "负责目标、用户、渠道、数据和竞争环境分析"

    def run(self, task: Task, step: Step, previous_outputs: List[Dict[str, Any]]) -> Dict[str, Any]:
        memory = self.tools.call("search_memory", namespace="ops", keyword=task.channel, limit=5)
        system = "你是资深运营分析师。输出要具体、可执行。"
        prompt = f"""
任务：{task.title}
目标：{task.goal}
渠道：{task.channel}
历史记忆：{dumps(memory)}
当前步骤输入：{dumps(step.input_data)}

请输出：
1. 目标拆解
2. 用户画像
3. 渠道特点
4. 核心指标
5. 主要风险
"""
        result = self.llm.complete(system, prompt)
        data = {
            "analysis": result,
            "kpi": ["曝光", "互动率", "私信数", "留资数", "转化率", "复购/留存"],
            "risks": ["平台规则变化", "话术违规", "执行频率过高", "数据没有闭环"],
        }
        self.tools.call("save_memory", namespace="ops", key=f"analysis:{task.id}", value=data)
        return data


class CopywriterAgent(Agent):
    name = "copywriter"
    role = "负责内容策略、标题、脚本、私信话术和转化文案"

    def run(self, task: Task, step: Step, previous_outputs: List[Dict[str, Any]]) -> Dict[str, Any]:
        system = "你是增长型内容运营和文案专家。注意平台合规，不要诱导违规操作。"
        prompt = f"""
任务：{task.title}
目标：{task.goal}
渠道：{task.channel}
上游输出：{dumps(previous_outputs)}
当前步骤输入：{dumps(step.input_data)}

请输出：
- 内容定位
- 7 天内容选题
- 3 条开场私信话术
- 3 条评论区互动话术
- 主页简介优化建议
- 禁止使用的高风险表达
"""
        raw = self.llm.complete(system, prompt)
        topics = [
            "痛点型：目标用户最常遇到的问题",
            "案例型：展示前后对比和过程",
            "干货型：3 个可马上用的方法",
            "避坑型：常见错误清单",
            "故事型：真实经历/客户视角",
            "互动型：提问收集需求",
            "转化型：引导用户主动咨询"
        ]
        scripts = [
            "你好呀，看你也关注这个方向，想了解哪一块？",
            "可以，我先简单了解下你的情况，再给你建议。",
            "方便说下你现在主要卡在哪一步吗？"
        ]
        data = {
            "content_plan_raw": raw,
            "seven_day_topics": topics,
            "dm_scripts": scripts,
            "comment_scripts": [
                "这个问题很多人都会遇到，我整理过一版清单。",
                "你现在是哪种情况？我可以按情况给你建议。",
                "这个点建议先看目标和预算，不要一上来就堆动作。"
            ],
            "bio_suggestions": [
                "一句话说明你帮谁解决什么问题",
                "突出结果而不是堆身份",
                "设置一个低压力的咨询入口"
            ],
            "avoid_words": ["保证", "百分百", "躺赚", "违规导流", "诱导私下交易"],
        }
        self.tools.call("save_memory", namespace="ops", key=f"copy:{task.id}", value=data)
        return data


class OpsAgent(Agent):
    name = "ops"
    role = "负责排期、SOP、人员分工、自动化动作和风险控制"

    def run(self, task: Task, step: Step, previous_outputs: List[Dict[str, Any]]) -> Dict[str, Any]:
        checklist = self.tools.call("generate_checklist", title=f"{task.title}执行清单", items=[
            "确认目标用户和转化路径",
            "准备 7 天内容素材",
            "发布并记录数据",
            "每天筛选高意向互动用户",
            "使用合规话术进行私信承接",
            "把线索录入 CRM 或表格",
            "每周复盘曝光、互动、私信、留资、成交"
        ])
        sop = {
            "daily": [
                "09:30 检查昨日数据",
                "11:30 发布一条内容",
                "15:00 回复评论和私信",
                "20:30 二次互动高意向用户",
                "22:00 记录数据并标记问题"
            ],
            "weekly": [
                "复盘 TOP3 内容",
                "淘汰低效选题",
                "优化主页和私信话术",
                "统计线索质量和成交反馈"
            ],
            "automation": [
                "自动采集内容数据",
                "自动提醒未回复私信",
                "自动生成每日报表",
                "自动识别高意向评论关键词"
            ]
        }
        data = {
            "sop": sop,
            "checklist": checklist,
            "risk_control": [
                "不要在公开内容中硬塞联系方式",
                "不要批量发送重复私信",
                "不要承诺无法验证的结果",
                "把引导改成让用户主动询问资料/方案/清单"
            ]
        }
        self.tools.call("save_memory", namespace="ops", key=f"sop:{task.id}", value=data)
        return data


class QAAgent(Agent):
    name = "qa"
    role = "负责质检、合规、可执行性和缺口分析"

    def run(self, task: Task, step: Step, previous_outputs: List[Dict[str, Any]]) -> Dict[str, Any]:
        combined = dumps(previous_outputs)
        score = self.tools.call("score_plan", plan_text=combined)
        system = "你是运营方案质检 Agent。检查合规性、可执行性、完整性。"
        prompt = f"""
请质检以下运营自动化输出：
任务：{task.title}
目标：{task.goal}
渠道：{task.channel}
内容：{combined}

返回 JSON，字段：
passed, score, issues, suggestions
"""
        qa = self.llm_json(system, prompt)
        if "score" not in qa:
            qa = {"passed": score["score"] >= 75, "score": score["score"], "issues": score["missing"], "suggestions": []}
        qa["auto_score"] = score
        return qa


class ExecutorAgent(Agent):
    name = "executor"
    role = "负责汇总、交付、模拟发布和通知"

    def run(self, task: Task, step: Step, previous_outputs: List[Dict[str, Any]]) -> Dict[str, Any]:
        final_doc = {
            "title": task.title,
            "goal": task.goal,
            "channel": task.channel,
            "created_at": now_iso(),
            "sections": previous_outputs,
            "next_actions": [
                "先选一个渠道做 7 天测试，不要一开始铺太多平台",
                "每天固定记录 5 个指标：曝光、互动、私信、留资、成交",
                "第三天开始优化标题和封面，第七天做完整复盘",
                "把高意向用户统一沉淀到表格或 CRM"
            ]
        }
        notify = self.tools.call("mock_notify", target="ops_team", content=dumps(final_doc)[:1000])
        self.tools.call("save_memory", namespace="ops", key=f"final:{task.id}", value=final_doc)
        return {
            "final": final_doc,
            "notify": notify
        }


# =========================
# 编排器
# =========================

class Orchestrator:
    def __init__(self, store: Store, llm: Optional[LLMClient] = None):
        self.store = store
        self.llm = llm or MockLLM()
        self.tools = ToolRegistry(store)
        self.planner = PlannerAgent(self.llm, self.tools, self.store)
        self.agents: Dict[str, Agent] = {
            "analyst": AnalystAgent(self.llm, self.tools, self.store),
            "copywriter": CopywriterAgent(self.llm, self.tools, self.store),
            "ops": OpsAgent(self.llm, self.tools, self.store),
            "qa": QAAgent(self.llm, self.tools, self.store),
            "executor": ExecutorAgent(self.llm, self.tools, self.store),
        }

    def create_steps_if_needed(self, task: Task) -> List[Step]:
        existing = self.store.list_steps(task.id)
        if existing:
            return existing

        planned = self.planner.plan(task)
        steps: List[Step] = []
        for i, p in enumerate(planned, 1):
            agent_name = p.get("agent_name", "ops")
            if agent_name not in self.agents:
                agent_name = "ops"
            step = Step(
                id=stable_id("step", task.id + str(i)),
                task_id=task.id,
                order_no=i,
                agent_name=agent_name,
                action=p.get("action", "run"),
                input_data=p.get("input_data", {}),
            )
            self.store.add_step(step)
            steps.append(step)
        return steps

    def run_task(self, task_id: str) -> Dict[str, Any]:
        task = self.store.get_task(task_id)
        if not task:
            raise ValueError(f"Task not found: {task_id}")

        self.store.update_task_status(task.id, TaskStatus.RUNNING)
        self.store.add_event(task.id, "info", "orchestration_started", {})

        previous_outputs: List[Dict[str, Any]] = []
        try:
            steps = self.create_steps_if_needed(task)
            for step in steps:
                if step.status == StepStatus.DONE:
                    previous_outputs.append(step.output_data)
                    continue

                agent = self.agents.get(step.agent_name)
                if not agent:
                    raise ValueError(f"Agent not found: {step.agent_name}")

                self.store.update_step(step.id, StepStatus.RUNNING)
                self.store.add_event(task.id, "info", "agent_started", {
                    "agent": agent.name,
                    "step_id": step.id,
                    "action": step.action
                })

                output = agent.run(task, step, previous_outputs)
                self.store.update_step(step.id, StepStatus.DONE, output_data=output)
                previous_outputs.append(output)

            self.store.update_task_status(task.id, TaskStatus.DONE)
            self.store.add_event(task.id, "info", "orchestration_done", {})
            return {
                "ok": True,
                "task_id": task.id,
                "status": "done",
                "outputs": previous_outputs
            }

        except Exception as e:
            err = traceback.format_exc()
            self.store.add_event(task.id, "error", "orchestration_failed", {"error": err})
            self.store.update_task_status(task.id, TaskStatus.FAILED)
            return {
                "ok": False,
                "task_id": task.id,
                "status": "failed",
                "error": str(e),
                "traceback": err
            }


# =========================
# 调度器
# =========================

class Scheduler:
    def __init__(self, store: Store, orchestrator: Orchestrator, poll_seconds: int = 5):
        self.store = store
        self.orchestrator = orchestrator
        self.poll_seconds = poll_seconds
        self._stop = threading.Event()

    def should_run(self, s: Schedule) -> bool:
        if not s.enabled:
            return False

        now = dt.datetime.now()
        ts = utc_ts()

        if s.kind == "once":
            if not s.run_at:
                return False
            run_at = dt.datetime.fromisoformat(s.run_at)
            return now >= run_at and s.last_run_ts == 0

        if s.kind == "interval":
            return ts - s.last_run_ts >= s.interval_seconds

        if s.kind == "daily":
            if not s.daily_time:
                return False
            hh, mm = map(int, s.daily_time.split(":"))
            target = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
            if now < target:
                return False
            # 当天已跑过就不再跑
            if s.last_run_ts:
                last = dt.datetime.fromtimestamp(s.last_run_ts)
                if last.date() == now.date():
                    return False
            return True

        return False

    def tick(self) -> None:
        schedules = self.store.list_schedules()
        for s in schedules:
            if self.should_run(s):
                task = self.store.create_task(
                    title=s.title,
                    goal=s.goal,
                    channel=s.channel,
                    metadata={"schedule_id": s.id}
                )
                self.store.mark_schedule_run(s.id)
                if s.kind == "once":
                    self.store.disable_schedule(s.id)
                self.orchestrator.run_task(task.id)

    def run_forever(self) -> None:
        print(f"[{now_iso()}] scheduler started, poll={self.poll_seconds}s")
        while not self._stop.is_set():
            try:
                self.tick()
            except KeyboardInterrupt:
                break
            except Exception:
                traceback.print_exc()
            time.sleep(self.poll_seconds)

    def stop(self) -> None:
        self._stop.set()


# =========================
# HTTP API
# =========================

class ApiHandler(http.server.BaseHTTPRequestHandler):
    store: Store = None  # type: ignore
    orchestrator: Orchestrator = None  # type: ignore

    def _send(self, code: int, data: Any) -> None:
        body = dumps(data).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self) -> Dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length).decode("utf-8") if length else "{}"
        return loads(body, {}) or {}

    def log_message(self, format: str, *args: Any) -> None:
        # 减少默认日志噪音
        sys.stderr.write("[%s] %s\n" % (now_iso(), format % args))

    def do_GET(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        qs = urllib.parse.parse_qs(parsed.query)

        try:
            if path == "/health":
                self._send(200, {"ok": True, "time": now_iso()})
                return

            if path == "/tasks":
                status = qs.get("status", [None])[0]
                limit = int(qs.get("limit", ["50"])[0])
                self._send(200, {"tasks": self.store.list_tasks(limit=limit, status=status)})
                return

            if path.startswith("/tasks/"):
                task_id = path.split("/")[-1]
                task = self.store.get_task(task_id)
                if not task:
                    self._send(404, {"error": "task not found"})
                    return
                steps = [dataclasses.asdict(s) for s in self.store.list_steps(task_id)]
                events = self.store.list_events(task_id=task_id, limit=100)
                self._send(200, {
                    "task": dataclasses.asdict(task),
                    "steps": steps,
                    "events": events
                })
                return

            if path == "/events":
                task_id = qs.get("task_id", [None])[0]
                self._send(200, {"events": self.store.list_events(task_id=task_id, limit=100)})
                return

            if path == "/schedules":
                self._send(200, {"schedules": [dataclasses.asdict(s) for s in self.store.list_schedules()]})
                return

            self._send(404, {"error": "not found"})

        except Exception as e:
            self._send(500, {"error": str(e), "traceback": traceback.format_exc()})

    def do_POST(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        body = self._read_json()

        try:
            if path == "/tasks":
                title = body.get("title") or "未命名运营任务"
                goal = body.get("goal") or body.get("content") or ""
                channel = body.get("channel") or "general"
                priority = int(body.get("priority", 5))
                run_now = bool(body.get("run_now", True))
                if not goal:
                    self._send(400, {"error": "goal is required"})
                    return

                task = self.store.create_task(title=title, goal=goal, channel=channel, priority=priority,
                                              metadata=body.get("metadata") or {})
                result = None
                if run_now:
                    result = self.orchestrator.run_task(task.id)

                self._send(200, {
                    "task": dataclasses.asdict(task),
                    "run_result": result
                })
                return

            if path == "/schedules":
                title = body.get("title") or "定时运营任务"
                goal = body.get("goal") or ""
                if not goal:
                    self._send(400, {"error": "goal is required"})
                    return
                kind = body.get("kind", "interval")
                schedule = Schedule(
                    id=stable_id("sch", title + goal),
                    title=title,
                    goal=goal,
                    channel=body.get("channel", "general"),
                    kind=kind,
                    interval_seconds=int(body.get("interval_seconds", 3600)),
                    run_at=body.get("run_at"),
                    daily_time=body.get("daily_time"),
                    enabled=bool(body.get("enabled", True)),
                )
                self.store.create_schedule(schedule)
                self._send(200, {"schedule": dataclasses.asdict(schedule)})
                return

            if path.startswith("/tasks/") and path.endswith("/run"):
                task_id = path.split("/")[-2]
                result = self.orchestrator.run_task(task_id)
                self._send(200, result)
                return

            self._send(404, {"error": "not found"})

        except Exception as e:
            self._send(500, {"error": str(e), "traceback": traceback.format_exc()})


def run_server(host: str, port: int, store: Store, orchestrator: Orchestrator) -> None:
    ApiHandler.store = store
    ApiHandler.orchestrator = orchestrator
    server = http.server.ThreadingHTTPServer((host, port), ApiHandler)
    print(f"[{now_iso()}] API server running at http://{host}:{port}")
    print("GET  /health")
    print("POST /tasks")
    print("GET  /tasks")
    print("GET  /tasks/{task_id}")
    print("POST /schedules")
    print("GET  /schedules")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


# =========================
# 可选：真实 LLM 接入示例
# =========================

class SimpleHttpLLM(LLMClient):
    """
    这是一个通用 HTTP LLM 适配器示例。
    默认不启用，避免强依赖第三方库。
    你可以按自己的模型服务改这里。
    """

    def __init__(self, endpoint: str, api_key: str = "", model: str = "default"):
        self.endpoint = endpoint
        self.api_key = api_key
        self.model = model

    def complete(self, system: str, prompt: str, temperature: float = 0.3) -> str:
        import urllib.request

        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": prompt}
            ],
            "temperature": temperature,
        }
        req = urllib.request.Request(
            self.endpoint,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                **({"Authorization": f"Bearer {self.api_key}"} if self.api_key else {})
            },
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = json.loads(resp.read().decode("utf-8"))

        # 兼容常见返回结构
        if isinstance(data, dict):
            if "choices" in data:
                return data["choices"][0]["message"]["content"]
            if "content" in data:
                return data["content"]
            if "text" in data:
                return data["text"]
        return json.dumps(data, ensure_ascii=False)


def build_llm_from_env() -> LLMClient:
    endpoint = os.getenv("LLM_ENDPOINT", "").strip()
    api_key = os.getenv("LLM_API_KEY", "").strip()
    model = os.getenv("LLM_MODEL", "default").strip()
    if endpoint:
        return SimpleHttpLLM(endpoint=endpoint, api_key=api_key, model=model)
    return MockLLM()


# =========================
# CLI
# =========================

def cmd_task(args: argparse.Namespace) -> None:
    store = Store(args.db)
    orch = Orchestrator(store, build_llm_from_env())
    task = store.create_task(
        title=args.title or args.goal[:30],
        goal=args.goal,
        channel=args.channel,
        priority=args.priority,
    )
    result = orch.run_task(task.id)
    print(dumps(result))
    print("\n查看详情：")
    print(f"python main.py show {task.id}")


def cmd_show(args: argparse.Namespace) -> None:
    store = Store(args.db)
    task = store.get_task(args.task_id)
    if not task:
        print("Task not found")
        return
    steps = store.list_steps(args.task_id)
    events = store.list_events(args.task_id, limit=100)
    print("=== TASK ===")
    print(dumps(dataclasses.asdict(task)))
    print("\n=== STEPS ===")
    print(dumps([dataclasses.asdict(s) for s in steps]))
    print("\n=== EVENTS ===")
    print(dumps(events))


def cmd_serve(args: argparse.Namespace) -> None:
    store = Store(args.db)
    orch = Orchestrator(store, build_llm_from_env())
    run_server(args.host, args.port, store, orch)


def cmd_worker(args: argparse.Namespace) -> None:
    store = Store(args.db)
    orch = Orchestrator(store, build_llm_from_env())
    scheduler = Scheduler(store, orch, poll_seconds=args.poll)
    scheduler.run_forever()


def cmd_schedule(args: argparse.Namespace) -> None:
    store = Store(args.db)
    s = Schedule(
        id=stable_id("sch", args.title + args.goal),
        title=args.title,
        goal=args.goal,
        channel=args.channel,
        kind=args.kind,
        interval_seconds=args.interval_seconds,
        run_at=args.run_at,
        daily_time=args.daily_time,
    )
    store.create_schedule(s)
    print(dumps(dataclasses.asdict(s)))


def cmd_seed(args: argparse.Namespace) -> None:
    store = Store(args.db)
    samples = [
        ("小红书", "适合做种草、案例、避坑、清单型内容。公开区不要硬放联系方式。"),
        ("抖音", "适合短视频强钩子、评论互动、直播承接。要注意重复私信和夸大承诺风险。"),
        ("私域", "适合承接高意向用户，用标签、SOP、复盘表提升转化。"),
    ]
    for k, v in samples:
        store.set_knowledge("ops", f"channel:{k}", {"channel": k, "notes": v})
    print("seed ok")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Multi-Agent 协同运营自动化系统")
    p.add_argument("--db", default="ops_agent.db", help="SQLite DB path")

    sub = p.add_subparsers(dest="cmd", required=True)

    t = sub.add_parser("task", help="创建并执行一个任务")
    t.add_argument("goal", help="运营目标")
    t.add_argument("--title", default="", help="任务标题")
    t.add_argument("--channel", default="general", help="渠道，例如 xiaohongshu/douyin/wechat")
    t.add_argument("--priority", type=int, default=5)
    t.set_defaults(func=cmd_task)

    s = sub.add_parser("show", help="查看任务详情")
    s.add_argument("task_id")
    s.set_defaults(func=cmd_show)

    sv = sub.add_parser("serve", help="启动 HTTP API")
    sv.add_argument("--host", default="127.0.0.1")
    sv.add_argument("--port", type=int, default=8765)
    sv.set_defaults(func=cmd_serve)

    w = sub.add_parser("worker", help="启动调度器")
    w.add_argument("--poll", type=int, default=5)
    w.set_defaults(func=cmd_worker)

    sc = sub.add_parser("schedule", help="创建定时任务")
    sc.add_argument("--title", required=True)
    sc.add_argument("--goal", required=True)
    sc.add_argument("--channel", default="general")
    sc.add_argument("--kind", choices=["once", "interval", "daily"], default="interval")
    sc.add_argument("--interval-seconds", type=int, default=3600)
    sc.add_argument("--run-at", default=None, help="once 模式：2026-05-05T10:00:00")
    sc.add_argument("--daily-time", default=None, help="daily 模式：HH:MM")
    sc.set_defaults(func=cmd_schedule)

    seed = sub.add_parser("seed", help="写入示例运营知识")
    seed.set_defaults(func=cmd_seed)

    return p


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
