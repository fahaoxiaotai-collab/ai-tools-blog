
# Multi-Agent 协同运营自动化系统

这是一个完整可运行的多 Agent 运营自动化系统骨架，适合改造成：

- 小红书 / 抖音 / 私域运营自动化
- 内容选题自动化
- 私信承接 SOP
- 线索跟进
- 每日数据复盘
- 多 Agent 自动协同执行任务

## 1. 快速启动

```bash
cd multi_agent_ops_system
python main.py seed
python main.py task "帮我做一套小红书 7 天引流运营方案" --title "小红书引流方案" --channel xiaohongshu
```

查看结果：

```bash
python main.py show <task_id>
```

启动 API：

```bash
python main.py serve
```

创建任务：

```bash
curl -X POST http://127.0.0.1:8765/tasks \
  -H "Content-Type: application/json" \
  -d '{"title":"小红书引流方案","goal":"做一套小红书7天引流运营方案","channel":"xiaohongshu"}'
```

启动定时任务调度器：

```bash
python main.py worker
```

创建定时任务：

```bash
python main.py schedule \
  --title "每日运营复盘" \
  --goal "复盘今天小红书内容数据，给出明天优化动作" \
  --channel xiaohongshu \
  --kind daily \
  --daily-time 22:00
```

## 2. 系统架构

```text
用户/API
  ↓
Task Store(SQLite)
  ↓
Orchestrator 编排器
  ↓
PlannerAgent 任务拆解
  ↓
AnalystAgent 分析
  ↓
CopywriterAgent 内容和话术
  ↓
OpsAgent SOP 和排期
  ↓
QAAgent 质检
  ↓
ExecutorAgent 汇总、通知、发布
  ↓
Memory / Event / Schedule
```

## 3. Agent 分工

| Agent | 职责 |
|---|---|
| PlannerAgent | 把目标拆成步骤 |
| AnalystAgent | 分析目标、用户、渠道、指标、风险 |
| CopywriterAgent | 生成内容策略、选题、私信话术、评论话术 |
| OpsAgent | 生成 SOP、排期、自动化动作、风险控制 |
| QAAgent | 合规、完整性、可执行性质检 |
| ExecutorAgent | 汇总最终交付物，模拟通知 |

## 4. 接真实大模型

默认用 `MockLLM`，不用 API Key 也能跑。

如果你有自己的兼容 HTTP 大模型接口，可以设置：

```bash
export LLM_ENDPOINT="https://your-llm-endpoint/v1/chat/completions"
export LLM_API_KEY="your_api_key"
export LLM_MODEL="your_model"
python main.py task "生成一套抖音运营方案" --channel douyin
```

如果你的接口返回结构不同，改 `SimpleHttpLLM.complete()` 这一段即可。

## 5. 接真实平台

在 `ToolRegistry.register_defaults()` 里替换这些模拟工具：

- `mock_publish`：接小红书、抖音、公众号、Notion、飞书等
- `mock_notify`：接企业微信、飞书、邮件、短信
- `save_memory/search_memory`：可换成向量数据库
- `score_plan`：可接你自己的风控/合规模型

## 6. 生产化建议

下一步建议拆成这些模块：

```text
app/
  agents/
  tools/
  api/
  scheduler/
  storage/
  llm/
  config/
```

再补：

- 登录鉴权
- 队列系统，比如 Redis/RabbitMQ
- 异步 worker
- 平台 API 签名
- Webhook 触发
- 向量检索
- 人工审核节点
- 审计日志
- 权限隔离
```
